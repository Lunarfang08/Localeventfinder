import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ImageBackground,
  RefreshControl,
  StyleSheet,
  Dimensions,
  Platform,
  SafeAreaView,
  Animated,
  Image
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { BlurView } from 'expo-blur';

const { width, height } = Dimensions.get('window');
const scale = (size: number) => (width / 375) * size;

const categories = [
  { id: 1, name: 'Music', icon: 'musical-notes', color: '#FF4757' },
  { id: 2, name: 'Sports', icon: 'basketball', color: '#1E90FF' },
  { id: 3, name: 'Arts', icon: 'color-palette', color: '#8A2BE2' },
  { id: 4, name: 'Food', icon: 'restaurant', color: '#FF8C00' },
  { id: 5, name: 'Tech', icon: 'laptop', color: '#20B2AA' },
  { id: 6, name: 'Outdoor', icon: 'leaf', color: '#3CB371' },
  { id: 7, name: 'Nightlife', icon: 'wine', color: '#9932CC' },
  { id: 8, name: 'Community', icon: 'people', color: '#4682B4' },
];


// Update: Fix for apostrophe string bug
const events = [
  {
    id: 1,
    title: 'Bolton Summer Festival',
    date: 'July 15-17, 2025',
    location: 'Bolton Town Square',
    image: 'https://api.a0.dev/assets/image?text=summer+festival+celebration+with+people+enjoying+music+and+food&aspect=16:9',
    price: '£25',
    description: "Join us for the biggest summer celebration in Bolton! Featuring live music, local food vendors, arts & crafts, and family activities.",
    time: '12:00 PM - 10:00 PM',
    organizer: 'Bolton City Council',
    category: 'Music',
    attendees: 850,
    distance: '1.2 km'
  },
  {
    id: 2,
    title: 'Tech Innovation Summit',
    date: 'August 5, 2025',
    location: 'Bolton Innovation Center',
    image: 'https://api.a0.dev/assets/image?text=modern+tech+conference+with+speakers+and+audience&aspect=16:9',
    price: '£50',
    description: 'Explore the latest in technology trends and innovations. Network with industry leaders and attend workshops.',
    time: '9:00 AM - 5:00 PM',
    organizer: 'TechHub Bolton',
    category: 'Tech',
    attendees: 430,
    distance: '3.5 km',
    trending: true
  },
  {
    id: 3,
    title: 'Bolton Food Festival',
    date: 'September 1-3, 2025',
    location: 'Victoria Square',
    image: 'https://api.a0.dev/assets/image?text=food+festival+with+various+cuisine+stalls+and+happy+people&aspect=16:9',
    price: 'Free Entry',
    description: 'Experience the best local and international cuisine. Celebrity chef demonstrations, food stalls, and live entertainment.',
    time: '11:00 AM - 9:00 PM',
    organizer: 'Bolton Food Network',
    category: 'Food',
    attendees: 1200,
    distance: '0.8 km',
    trending: true
  },
    {
    id: 4,
    title: 'Bolton Farmers Market',
    date: 'Every Saturday',
    location: 'Market Place',
    image: 'https://api.a0.dev/assets/image?text=farmers+market+with+fresh+produce+and+shoppers&aspect=16:9',
    price: 'Free Entry',
    description: "Shop for fresh local produce, artisanal foods, and handmade crafts at Bolton's weekly farmers market.",
    time: '9:00 AM - 2:00 PM',
    organizer: 'Bolton Market Association',
    category: 'Food',
    attendees: 300,
    distance: '1.5 km'
  },
  {
    id: 5,
    title: 'Bolton FC vs Manchester United',
    date: 'August 12, 2025',
    location: 'University of Bolton Stadium',
    image: 'https://api.a0.dev/assets/image?text=soccer+match+stadium+filled+with+fans&aspect=16:9',
    price: '£35 - £120',
    description: 'Watch Bolton FC take on Manchester United in this exciting Premier League match.',
    time: '7:45 PM',
    organizer: 'Bolton FC',
    category: 'Sports',
    attendees: 28000,
    distance: '4.2 km',
    trending: true
  },
  {
    id: 6,
    title: 'Bolton Craft Beer Festival',
    date: 'July 28-30, 2025',
    location: 'The Market Hall',
    image: 'https://api.a0.dev/assets/image?text=craft+beer+festival+with+brewers+and+tasting&aspect=16:9',
    price: '£15',
    description: 'Sample over 100 craft beers from local and international breweries, plus food pairings and live music.',
    time: '12:00 PM - 11:00 PM',
    organizer: 'Bolton Brewers Guild',
    category: 'Nightlife',
    attendees: 650,
    distance: '1.9 km'
  },
];

const thisWeekEvents = [
  {
    id: 7,
    title: 'Weekend Art Workshop',
    date: 'April 12, 2025',
    location: 'Bolton Art Gallery',
    image: 'https://api.a0.dev/assets/image?text=art+workshop+people+painting&aspect=16:9',
    category: 'Arts',
    price: '£10',
    distance: '0.9 km'
  },
  {
    id: 8, 
    title: 'Community Garden Day',
    date: 'April 13, 2025',
    location: 'Queens Park',
    image: 'https://api.a0.dev/assets/image?text=community+gardening+people+planting&aspect=16:9',
    category: 'Outdoor',
    price: 'Free',
    distance: '2.3 km'
  },
  {
    id: 9,
    title: 'Coding Bootcamp',
    date: 'April 14, 2025',
    location: 'Bolton Digital Hub',
    image: 'https://api.a0.dev/assets/image?text=coding+workshop+laptops&aspect=16:9',
    category: 'Tech',
    price: '£5',
    distance: '1.7 km'
  }
];
const featuredEvent = {
  id: 0,
  title: 'Bolton Cultural Festival',
  date: 'July 10-12, 2025',
  location: 'Bolton Central Park',
  image: 'https://api.a0.dev/assets/image?text=cultural+festival+with+performances+stage+and+audience&aspect=16:9',
  price: '£15',
  isFeatured: true,
  description: "Experience cultures from around the world with music, dance, and cuisine at Bolton's annual cultural celebration.",
  time: '11:00 AM - 11:00 PM',
  organizer: 'Bolton Cultural Society',
  category: 'Arts',
  attendees: 1240
};

export default function HomeScreen() {
  const navigation = useNavigation();
  const [refreshing, setRefreshing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [bookmarkedEvents, setBookmarkedEvents] = useState<number[]>([]);
  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const scrollY = useRef(new Animated.Value(0)).current;
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(20)).current;
  
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(translateY, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      })
    ]).start();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  const toggleBookmark = (eventId: number) => {
    setBookmarkedEvents(prev =>
      prev.includes(eventId)
        ? prev.filter(id => id !== eventId)
        : [...prev, eventId]
    );
  };

  const handleEventPress = (event: any) => {
    navigation.navigate('EventDetails', { event });
  };

  const filterByCategoryColor = (categoryName: string) => {
    const category = categories.find(c => c.name === categoryName);
    return category ? category.color : '#FF4757';
  };

  const filteredEvents = selectedCategory === 'All'
    ? events
    : events.filter(event => event.category === selectedCategory);
    
  const trendingEvents = events.filter(event => event.trending);
  
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [0, 1],
    extrapolate: 'clamp',
  });

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Floating header background on scroll */}
      <Animated.View 
        style={[
          styles.floatingHeader, 
          { opacity: headerOpacity }
        ]}
      >
        <BlurView intensity={80} style={styles.blurView} tint="light" />
      </Animated.View>
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.locationContainer}
          onPress={() => setShowLocationPicker(!showLocationPicker)}
        >
          <Ionicons name="location" size={24} color="#FF4757" />
          <View>
            <Text style={styles.locationLabel}>Current Location</Text>
            <View style={styles.locationTextContainer}>
              <Text style={styles.locationText}>Bolton, UK</Text>
              <Ionicons name="chevron-down" size={16} color="#747D8C" />
            </View>
          </View>
        </TouchableOpacity>
        
        <View style={styles.headerRightActions}>
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="notifications-outline" size={24} color="#2F3542" />
            <View style={styles.notificationBadge}>
              <Text style={styles.notificationBadgeText}>3</Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity style={styles.profileButton}>
            <Image 
              source={{ uri: 'https://api.a0.dev/assets/image?text=profile+avatar+person&aspect=1:1' }} 
              style={styles.profileImage} 
            />
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Location selector dropdown */}
      {showLocationPicker && (
        <View style={styles.locationPicker}>
          <TouchableOpacity style={styles.locationOption}>
            <Ionicons name="location" size={20} color="#FF4757" />
            <Text style={styles.locationOptionText}>Bolton, UK (Current)</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.locationOption}>
            <Ionicons name="location-outline" size={20} color="#747D8C" />
            <Text style={styles.locationOptionText}>Manchester, UK</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.locationOption}>
            <Ionicons name="add-circle-outline" size={20} color="#747D8C" />
            <Text style={styles.locationOptionText}>Add new location</Text>
          </TouchableOpacity>
        </View>
      )}

      <Animated.ScrollView
        style={[styles.container, { opacity: fadeAnim, transform: [{ translateY }] }]}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
        }
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: true }
        )}
        scrollEventThrottle={16}
      >
        {/* Search and Quick Actions */}
        <View style={styles.searchContainer}>
          <TouchableOpacity style={styles.searchBar}>
            <Ionicons name="search" size={20} color="#747D8C" />
            <Text style={styles.searchText}>Search events...</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.filterButton}>
            <Ionicons name="options-outline" size={22} color="#FFF" />
          </TouchableOpacity>
        </View>
        
        {/* Quick Action Buttons */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickActionButton}>
            <View style={[styles.quickActionIcon, { backgroundColor: '#FF4757' }]}>
              <Ionicons name="calendar" size={20} color="#FFF" />
            </View>
            <Text style={styles.quickActionText}>Create</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.quickActionButton}>
            <View style={[styles.quickActionIcon, { backgroundColor: '#1E90FF' }]}>
              <Ionicons name="compass" size={20} color="#FFF" />
            </View>
            <Text style={styles.quickActionText}>Nearby</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.quickActionButton}>
            <View style={[styles.quickActionIcon, { backgroundColor: '#20B2AA' }]}>
              <Ionicons name="bookmark" size={20} color="#FFF" />
            </View>
            <Text style={styles.quickActionText}>Saved</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.quickActionButton}>
            <View style={[styles.quickActionIcon, { backgroundColor: '#9932CC' }]}>
              <Ionicons name="ticket" size={20} color="#FFF" />
            </View>
            <Text style={styles.quickActionText}>Tickets</Text>
          </TouchableOpacity>
        </View>

        {/* Featured Event Banner */}
        <TouchableOpacity 
          style={styles.featuredEventContainer}
          onPress={() => handleEventPress(featuredEvent)}
        >
          <Text style={styles.sectionHeader}>Featured Event</Text>
          <ImageBackground
            source={{ uri: featuredEvent.image }}
            style={styles.featuredEventImage}
            imageStyle={styles.featuredEventImageStyle}
          >
            <LinearGradient
              colors={['rgba(0,0,0,0.3)', 'rgba(0,0,0,0.8)']}
              style={styles.featuredGradient}
            >
              <View style={styles.featuredContent}>
                <View style={styles.featuredBadge}>
                  <Ionicons name="star" size={12} color="#FFF" />
                  <Text style={styles.featuredBadgeText}>Featured</Text>
                </View>
                
                <Text style={styles.featuredTitle}>{featuredEvent.title}</Text>
                
                <View style={styles.featuredDetails}>
                  <View style={styles.featuredDetail}>
                    <Ionicons name="calendar" size={16} color="#FFF" />
                    <Text style={styles.featuredDetailText}>{featuredEvent.date}</Text>
                  </View>
                  
                  <View style={styles.featuredDetail}>
                    <Ionicons name="location" size={16} color="#FFF" />
                    <Text style={styles.featuredDetailText}>{featuredEvent.location}</Text>
                  </View>
                  
                  <View style={styles.featuredDetail}>
                    <Ionicons name="people" size={16} color="#FFF" />
                    <Text style={styles.featuredDetailText}>{featuredEvent.attendees} going</Text>
                  </View>
                </View>
                
                <TouchableOpacity style={styles.featuredButton}>
                  <Text style={styles.featuredButtonText}>View Details</Text>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </ImageBackground>
        </TouchableOpacity>

        {/* This Week Section */}
        <View style={styles.thisWeekContainer}>
          <View style={styles.sectionHeaderContainer}>
            <Text style={styles.sectionHeader}>This Week</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.thisWeekEventsContainer}
          >
            {thisWeekEvents.map(event => (
              <TouchableOpacity 
                key={`week-${event.id}`}
                style={styles.thisWeekEventCard}
                onPress={() => handleEventPress(event)}
              >
                <ImageBackground
                  source={{ uri: event.image }}
                  style={styles.thisWeekEventImage}
                  imageStyle={styles.thisWeekEventImageStyle}
                >
                  <View style={[styles.categoryTag, { backgroundColor: filterByCategoryColor(event.category) }]}>
                    <Text style={styles.categoryTagText}>{event.category}</Text>
                  </View>
                </ImageBackground>
                
                <View style={styles.thisWeekEventInfo}>
                  <Text style={styles.thisWeekEventTitle} numberOfLines={1}>{event.title}</Text>
                  
                  <View style={styles.thisWeekEventDetails}>
                    <View style={styles.thisWeekEventDetail}>
                      <Ionicons name="calendar-outline" size={14} color="#747D8C" />
                      <Text style={styles.thisWeekEventDetailText}>{event.date}</Text>
                    </View>
                    
                    <View style={styles.thisWeekEventDetail}>
                      <Ionicons name="location-outline" size={14} color="#747D8C" />
                      <Text style={styles.thisWeekEventDetailText}>{event.distance}</Text>
                    </View>
                  </View>
                  
                  <View style={styles.thisWeekEventPrice}>
                    <Text style={styles.thisWeekEventPriceText}>{event.price}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* Categories */}
        <View style={styles.categoriesMainContainer}>
          <Text style={styles.sectionHeader}>Categories</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesContainer}
          >
            <TouchableOpacity
              style={[styles.categoryPill, selectedCategory === 'All' && styles.selectedCategory]}
              onPress={() => setSelectedCategory('All')}
            >
              <Ionicons name="apps" size={20} color={selectedCategory === 'All' ? '#FFF' : '#2F3542'} />
              <Text style={[styles.categoryText, selectedCategory === 'All' && styles.selectedCategoryText]}>All</Text>
            </TouchableOpacity>
            {categories.map(category => (
              <TouchableOpacity
                key={category.id}
                style={[
                  styles.categoryPill, 
                  selectedCategory === category.name && styles.selectedCategory,
                  selectedCategory === category.name && { backgroundColor: category.color, borderColor: category.color }
                ]}
                onPress={() => setSelectedCategory(category.name)}
              >
                <Ionicons
                  name={category.icon as any}
                  size={20}
                  color={selectedCategory === category.name ? '#FFF' : '#2F3542'}
                />
                <Text style={[styles.categoryText, selectedCategory === category.name && styles.selectedCategoryText]}>
                  {category.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* Trending Events */}
        {selectedCategory === 'All' && (
          <View style={styles.trendingContainer}>
            <View style={styles.sectionHeaderContainer}>
              <Text style={styles.sectionHeader}>Trending in Bolton</Text>
              <TouchableOpacity>
                <Text style={styles.seeAllText}>See All</Text>
              </TouchableOpacity>
            </View>
            
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.trendingEventsContainer}
            >
              {trendingEvents.map(event => (
                <TouchableOpacity
                  key={`trending-${event.id}`}
                  style={styles.trendingEventCard}
                  onPress={() => handleEventPress(event)}
                >
                  <ImageBackground
                    source={{ uri: event.image }}
                    style={styles.trendingEventImage}
                    imageStyle={styles.trendingEventImageStyle}
                  >
                    <LinearGradient
                      colors={['transparent', 'rgba(0,0,0,0.7)']}
                      style={styles.trendingGradient}
                    >
                      <View style={styles.trendingBadge}>
                        <Ionicons name="trending-up" size={12} color="#FFF" />
                        <Text style={styles.trendingBadgeText}>Trending</Text>
                      </View>
                      
                      <Text style={styles.trendingEventTitle}>{event.title}</Text>
                      
                      <View style={styles.trendingEventDetails}>
                        <View style={styles.trendingEventDetail}>
                          <Ionicons name="calendar-outline" size={14} color="#FFF" />
                          <Text style={styles.trendingEventDetailText}>{event.date}</Text>
                        </View>
                        
                        <View style={styles.trendingEventDetail}>
                          <Ionicons name="location-outline" size={14} color="#FFF" />
                          <Text style={styles.trendingEventDetailText}>{event.location}</Text>
                        </View>
                      </View>
                    </LinearGradient>
                  </ImageBackground>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Events List Header */}
        <View style={styles.eventsListHeader}>
          <Text style={styles.sectionHeader}>
            {selectedCategory === 'All' ? 'All Events' : `${selectedCategory} Events`}
          </Text>
          <View style={styles.eventsListActions}>
            <TouchableOpacity style={styles.sortButton}>
              <Ionicons name="funnel-outline" size={18} color="#747D8C" />
              <Text style={styles.sortButtonText}>Filter</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.sortButton}>
              <Ionicons name="swap-vertical-outline" size={18} color="#747D8C" />
              <Text style={styles.sortButtonText}>Sort</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Events List */}
        <View style={styles.eventsContainer}>
          {filteredEvents.length > 0 ? (
            filteredEvents.map(event => (
              <TouchableOpacity
                key={event.id}
                style={styles.eventCard}
                onPress={() => handleEventPress(event)}
              >
                <ImageBackground
                  source={{ uri: event.image }}
                  style={styles.eventImage}
                  imageStyle={styles.eventImageStyle}
                >
                  <View style={[styles.categoryTag, { backgroundColor: filterByCategoryColor(event.category) }]}>
                    <Text style={styles.categoryTagText}>{event.category}</Text>
                  </View>
                  
                  <LinearGradient
                    colors={['transparent', 'rgba(0,0,0,0.8)']}
                    style={styles.gradient}
                  >
                    <View style={styles.eventInfo}>
                      <View style={styles.eventHeader}>
                        <Text style={styles.eventTitle}>{event.title}</Text>
                        <TouchableOpacity
                          onPress={() => toggleBookmark(event.id)}
                          style={styles.bookmarkButton}
                        >
                          <Ionicons
                            name={bookmarkedEvents.includes(event.id) ? "bookmark" : "bookmark-outline"}
                            size={24}
                            color="#FFF"
                          />
                        </TouchableOpacity>
                      </View>
                      
                      <View style={styles.eventDetails}>
                        <View style={styles.eventDetail}>
                          <Ionicons name="calendar" size={16} color="#FFF" />
                          <Text style={styles.eventDetailText}>{event.date}</Text>
                        </View>
                        
                        <View style={styles.eventDetail}>
                          <Ionicons name="location" size={16} color="#FFF" />
                          <Text style={styles.eventDetailText}>{event.location}</Text>
                        </View>
                        
                        <View style={styles.eventExtraDetails}>
                          <View style={styles.eventDetail}>
                            <Ionicons name="people" size={16} color="#FFF" />
                            <Text style={styles.eventDetailText}>{event.attendees} going</Text>
                          </View>
                          
                          <View style={styles.eventPriceTag}>
                            <Text style={styles.eventPriceText}>{event.price}</Text>
                          </View>
                        </View>
                      </View>
                    </View>
                  </LinearGradient>
                </ImageBackground>
              </TouchableOpacity>
            ))
          ) : (
            <View style={styles.noEventsContainer}>
              <Ionicons name="calendar-outline" size={60} color="#CED4DA" />
              <Text style={styles.noEventsText}>No {selectedCategory} events found</Text>
              <TouchableOpacity 
                style={styles.resetFilterButton}
                onPress={() => setSelectedCategory('All')}
              >
                <Text style={styles.resetFilterText}>Show All Events</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </Animated.ScrollView>
      
      {/* Floating action button */}
      <TouchableOpacity style={styles.floatingButton}>
        <LinearGradient
          colors={['#FF4757', '#FF7B69']}
          style={styles.gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <Ionicons name="add" size={28} color="#FFF" />
        </LinearGradient>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
// Updated styles with better responsiveness
// Enhanced responsive styles addressing the search bar and other specific issues
// Enhanced responsive styles with smooth animations and better scaling
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    paddingTop: Platform.OS === 'android' ? scale(25) : 0,
  },
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.04,
    paddingVertical: height * 0.015,
    backgroundColor: '#FFF',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#F0F0F0',
    zIndex: 20,
  },
  searchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: height * 0.015,
    marginBottom: height * 0.01,
    marginHorizontal: width * 0.04,
    height: scale(44),
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F7',
    borderRadius: scale(12),
    paddingVertical: scale(10),
    paddingHorizontal: scale(12),
    marginRight: scale(8),
    height: '100%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  eventCard: {
    marginBottom: height * 0.015,
    borderRadius: scale(16),
    backgroundColor: '#FFF',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
    transform: [{ scale: 1 }],
  },
  featuredEventImage: {
    width: '100%',
    height: width * 0.5,
    borderRadius: scale(16),
    overflow: 'hidden',
  },
  thisWeekEventCard: {
    width: width * 0.38,
    marginRight: scale(12),
    borderRadius: scale(16),
    backgroundColor: '#FFF',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 3,
  },
  categoryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: scale(12),
    paddingVertical: scale(8),
    borderRadius: scale(20),
    marginRight: scale(8),
    backgroundColor: '#FFF',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#E9ECEF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  floatingButton: {
    position: 'absolute',
    bottom: height * 0.03,
    right: width * 0.04,
    width: scale(56),
    height: scale(56),
    borderRadius: scale(28),
    overflow: 'hidden',
    shadowColor: '#FF4757',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  // Main container styles
  safeArea: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    paddingTop: Platform.OS === 'android' ? scale(25) : 0,
  },
  container: {
    flex: 1,
  },
  
  // Improved header and search bar section
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.04,
    paddingVertical: height * 0.012,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    zIndex: 20,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    maxWidth: width * 0.65,
  },
  locationLabel: {
    fontSize: scale(10),
    color: '#747D8C',
    marginLeft: scale(6),
  },
  locationTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: scale(6),
  },
  locationText: {
    fontSize: scale(14),
    fontWeight: '600',
    color: '#2F3542',
    marginRight: scale(4),
    maxWidth: width * 0.4,
  },
  headerRightActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    padding: scale(6),
    marginRight: scale(6),
  },
  
  // Fixed search bar styling
  searchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: scale(10),
    marginBottom: scale(6),
    marginHorizontal: width * 0.04,
    height: scale(40),
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F7',
    borderRadius: scale(8),
    paddingVertical: scale(8),
    paddingHorizontal: scale(12),
    marginRight: scale(8),
    height: '100%',
  },
  searchText: {
    marginLeft: scale(6),
    color: '#747D8C',
    fontSize: scale(13),
  },
  
  // Quick actions - proper spacing and alignment
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: width * 0.04,
    marginVertical: scale(12),
  },
  quickActionButton: {
    alignItems: 'center',
    width: (width - (width * 0.08) - scale(15)) / 4,
  },
  quickActionIcon: {
    width: scale(36),
    height: scale(36),
    borderRadius: scale(18),
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: scale(4),
  },
  quickActionText: {
    fontSize: scale(11),
    color: '#2F3542',
    textAlign: 'center',
  },
  
  // Featured event section - improved sizing
  featuredEventContainer: {
    marginTop: scale(10),
    marginHorizontal: width * 0.04,
  },
  sectionHeader: {
    fontSize: scale(16),
    fontWeight: '700',
    color: '#2F3542',
    marginBottom: scale(8),
  },
  featuredEventImage: {
    width: '100%',
    height: width * 0.45,
    borderRadius: scale(12),
    overflow: 'hidden',
  },
  featuredEventImageStyle: {
    borderRadius: scale(12),
  },
  featuredGradient: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: scale(12),
  },
  featuredContent: {
    gap: scale(6),
  },
  featuredBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF4757',
    paddingHorizontal: scale(6),
    paddingVertical: scale(3),
    borderRadius: scale(4),
    alignSelf: 'flex-start',
  },
  featuredBadgeText: {
    color: '#FFF',
    fontSize: scale(10),
    marginLeft: scale(3),
    fontWeight: '600',
  },
  featuredTitle: {
    fontSize: scale(16),
    fontWeight: 'bold',
    color: '#FFF',
  },
  featuredDetails: {
    gap: scale(3),
  },
  featuredDetail: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: scale(4),
  },
  featuredDetailText: {
    color: '#FFF',
    fontSize: scale(12),
  },
  
  // This Week section - improved card layout
  thisWeekContainer: {
    marginTop: scale(16),
    marginHorizontal: width * 0.04,
  },
  sectionHeaderContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: scale(8),
  },
  seeAllText: {
    color: '#FF4757',
    fontSize: scale(12),
    fontWeight: '600',
  },
  thisWeekEventsContainer: {
    paddingBottom: scale(8),
  },
  thisWeekEventCard: {
    width: width * 0.36,
    marginRight: scale(10),
    borderRadius: scale(10),
    backgroundColor: '#FFF',
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  thisWeekEventImage: {
    width: '100%',
    height: width * 0.24,
  },
  thisWeekEventImageStyle: {
    borderTopLeftRadius: scale(10),
    borderTopRightRadius: scale(10),
  },
  categoryTag: {
    position: 'absolute',
    top: scale(6),
    left: scale(6),
    paddingHorizontal: scale(6),
    paddingVertical: scale(2),
    borderRadius: scale(4),
  },
  categoryTagText: {
    color: '#FFF',
    fontSize: scale(9),
    fontWeight: '600',
  },
  thisWeekEventInfo: {
    padding: scale(8),
  },
  thisWeekEventTitle: {
    fontSize: scale(12),
    fontWeight: '600',
    color: '#2F3542',
    marginBottom: scale(4),
  },
  thisWeekEventDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: scale(4),
  },
  thisWeekEventDetail: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  thisWeekEventDetailText: {
    fontSize: scale(10),
    color: '#747D8C',
    marginLeft: scale(3),
  },
  thisWeekEventPrice: {
    backgroundColor: '#F1F3F5',
    alignSelf: 'flex-start',
    paddingHorizontal: scale(6),
    paddingVertical: scale(2),
    borderRadius: scale(4),
  },
  thisWeekEventPriceText: {
    color: '#2F3542',
    fontSize: scale(10),
    fontWeight: '600',
  },
  
  // Categories section - improved pills
  categoriesMainContainer: {
    marginTop: scale(16),
    marginHorizontal: width * 0.04,
  },
  categoriesContainer: {
    paddingBottom: scale(8),
  },
  categoryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: scale(10),
    paddingVertical: scale(6),
    borderRadius: scale(16),
    marginRight: scale(8),
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#E9ECEF',
  },
  selectedCategory: {
    backgroundColor: '#FF4757',
    borderColor: '#FF4757',
  },
  categoryText: {
    marginLeft: scale(4),
    fontSize: scale(12),
    color: '#2F3542',
  },
  selectedCategoryText: {
    color: '#FFF',
  },
  
  // Additional utility styles
  blurView: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  floatingHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: Platform.OS === 'ios' ? scale(90) : scale(115),
    zIndex: 10,
  },
});