import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Image,
  Share,
  Alert,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import QRCode from 'react-native-qrcode-svg';

export default function BookingConfirmationScreen({ route, navigation }) {
  const { 
    event, 
    ticketCount, 
    totalPrice, 
    bookingRef,
    fullName,
    email,
    phone 
  } = route.params;

  const handleAddToCalendar = () => {
    // Add to calendar functionality
  };  const handleDownloadTicket = async () => {
    try {
      // Create ticket content
      const ticketContent = `
EVENT TICKET

${event.title}
Date: ${event.date}
Time: ${event.time}
Location: ${event.location}

Booking Reference: ${bookingRef}
Attendee: ${fullName}
Number of Tickets: ${ticketCount}
Total Paid: £${(totalPrice * 1.05).toFixed(2)}

Present this ticket at the venue
--------------------------------
      `;

      // Share the ticket
      await Share.share({
        title: `Ticket for ${event.title}`,
        message: ticketContent,
      });
      
      // Show success message
      Alert.alert(
        "Success!",
        Platform.OS === 'ios' 
          ? "Your ticket has been saved to Files"
          : "Your ticket has been downloaded",
        [{ text: "OK" }]
      );
    } catch (error) {
      Alert.alert(
        "Error",
        "Could not download ticket. Please try again.",
        [{ text: "OK" }]
      );
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Booking Confirmed!</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.successIcon}>
          <Ionicons name="checkmark-circle" size={64} color="#4CD964" />
        </View>

        <View style={styles.qrContainer}>
          <QRCode
            value={bookingRef}
            size={200}
          />
          <Text style={styles.bookingRef}>Booking Ref: {bookingRef}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Event Details</Text>
          <View style={styles.eventCard}>
            <Image 
              source={{ uri: event.image }} 
              style={styles.eventImage}
            />
            <View style={styles.eventInfo}>
              <Text style={styles.eventTitle}>{event.title}</Text>
              <Text style={styles.eventDetail}>{event.date}</Text>
              <Text style={styles.eventDetail}>{event.location}</Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Ticket Information</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Quantity:</Text>
            <Text style={styles.infoValue}>{ticketCount} tickets</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Total Paid:</Text>
            <Text style={styles.infoValue}>£{(totalPrice * 1.05).toFixed(2)}</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Contact Details</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Name:</Text>
            <Text style={styles.infoValue}>{fullName}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Email:</Text>
            <Text style={styles.infoValue}>{email}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Phone:</Text>
            <Text style={styles.infoValue}>{phone}</Text>
          </View>
        </View>

        <View style={styles.actions}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleAddToCalendar}
          >
            <Ionicons name="calendar" size={24} color="#FF4757" />
            <Text style={styles.actionButtonText}>Add to Calendar</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleDownloadTicket}
          >
            <Ionicons name="download" size={24} color="#FF4757" />
            <Text style={styles.actionButtonText}>Download Ticket</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity 
          style={styles.doneButton}
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.doneButtonText}>Done</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    padding: 16,
    paddingTop: 44,
    backgroundColor: '#FFF',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E9ECEF',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2F3542',
  },
  content: {
    padding: 16,
  },
  successIcon: {
    alignItems: 'center',
    marginVertical: 24,
  },
  qrContainer: {
    alignItems: 'center',
    backgroundColor: '#FFF',
    padding: 24,
    borderRadius: 12,
    marginBottom: 24,
  },
  bookingRef: {
    marginTop: 16,
    fontSize: 16,
    fontWeight: '600',
    color: '#2F3542',
  },
  section: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2F3542',
    marginBottom: 16,
  },
  eventCard: {
    flexDirection: 'row',
    backgroundColor: '#F8F9FA',
    borderRadius: 8,
    overflow: 'hidden',
  },
  eventImage: {
    width: 80,
    height: 80,
  },
  eventInfo: {
    flex: 1,
    padding: 12,
  },
  eventTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2F3542',
    marginBottom: 4,
  },
  eventDetail: {
    fontSize: 14,
    color: '#747D8C',
    marginBottom: 2,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  infoLabel: {
    fontSize: 14,
    color: '#747D8C',
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#2F3542',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
    padding: 16,
    borderRadius: 12,
    marginHorizontal: 8,
  },
  actionButtonText: {
    marginLeft: 8,
    fontSize: 14,
    fontWeight: '600',
    color: '#FF4757',
  },
  doneButton: {
    backgroundColor: '#FF4757',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  doneButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
});